<!DOCTYPE html>
<html>
<head>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons"  rel="stylesheet">
	<style>

	#maintitle{
		padding-right: 0px;
		padding-left: 0px;
		margin-bottom: 0px; 
		border-radius: 0px;
   		margin-top: 40px;
	}

	#mainbottom{
		padding-right: 0px;
		padding-left: 0px;
		margin-bottom: 0px; 
		border-radius: 0px;
   		
	}
	#formcontainer{
		background-color: blueviolet;
    	padding-top: 20px;
    	padding-bottom: 20px;
	}
	</style>
</head>
<body style="background-color: #bcbcbc;background: url(./img/back.png);background-size: cover">
	<div id="maintitle" class="container">
  		<div style="margin-bottom: 0px;border-radius: 0px;" class="jumbotron">
	    	<h2>Welcome to LAB SYSTEM MANAGEMENT</h2> 
	    	<h1>SETUP</h1> 
		    <p>Enter the credential to connect to mysql server</p> 
  		</div>
		  
	</div>
	<div id="formcontainer" class="container">
		<div class="row">
			<div class="col-sm-3">
			</div>
			<div class="col-sm-6">
				<form class="form" action=database/init.php method="POST">	<label> MYSQL SERVER INFO</label>
					<div class="form-group">
					<input type="text" name="servername" class="form-control" placeholder="Servername" required>
					</div>
					<div class="form-group">
					<input type="text" name="username" class="form-control" placeholder="Username" required>
					</div>
					<div class="form-group">
					<input type="Password" name="password" class="form-control" placeholder="Password" >
					</div>

					<label> ADMIN LOGIN INFO</label>
					
					<div class="form-group">
					<input type="text" name="uname" class="form-control" placeholder="Username" required>
					</div>
					<div class="form-group">
					<input type="Password" name="pword" class="form-control" placeholder="Password" required>
					</div>
					<input type="submit" class="btn btn-success" value="INSTALL">
				</form>
			</div>
			<div class="col-sm-3">
			</div>
		</div>
	</div>
	<div id="mainbottom" class="container ">
		<?php include "adBanner.php";?>
	</div>
</body>
</html>