<div  class="fluid-container" >
	<div class="row">
		<div class="col-sm-12">
			<div class="design" style=" background-color: #1b1b1b;padding: 15px">
				<center><h4>DESIGN AND DEVELOPED BY</h4></center>
				<center><h4>ASHWANI ARYA <a style="color: #333" href="http://www.syncoders.com">(www.syncoders.com)</a></h4></center>
			</div>
		</div>
	</div>
</div>