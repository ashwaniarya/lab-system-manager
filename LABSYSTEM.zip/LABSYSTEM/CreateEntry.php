
<html>
<head lang="en-US">

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<script>
	function validateForm(){
		return true;
	}
	</script>
</head>
	
<body>
	<div class="container">
		<div class="row">

			<div class="col-lg-3">
			</div>
			<div class="col-lg-6">
				<form name="add" action="/LABSYSTEM/Database/system/add.php" onsubmit="return validateForm()" method="post">
					
					
					<div class="form-group">
						<lable>Lab name:</lable>
						<input type="text" class="form-control" name="labcode">
					</div>

					<div class="form-group">
						<lable>Processor Details:</lable>
						<input type="text" class="form-control" name="processor_details">
					</div>

					<div class="form-group">
						<lable>Operating System:</lable>
						<input type="text" class="form-control" name="operating_system">
					</div>

					<div class="form-group">
						<lable>Ram:</lable>
						<input type="text" class="form-control" name="ram">
					</div>

					<div class="form-group">
						<lable>HDD:</lable>
						<input type="text" class="form-control" name="hdd">
					</div>

					<div class="form-group">
						<lable>Monitor Size:</lable>
						<input type="text" class="form-control" name="monitor_size">
					</div>
					
					<div class="checkbox">
						<lable><input type="checkbox" name="dvd" value="true">DVD:</lable>
					</div>

					<div class="form-group">
						<lable>Brand:</lable>
						<input type="text" class="form-control" name="brand">
					</div>

					<div class="form-group">
						<lable>Make and Year:</lable>
						<input type="text" class="form-control" name="make_and_year">
					</div>

					<div class="checkbox">
						<lable> <input type="checkbox" name="in_warrenty" value="true">In Warrenty:</lable>
					</div>

					<input type="submit" value="Submit">
				</form>
			</div>
			<div class="col-lg-3">
			</div>
		</div>
	</div>
</body>
</html>