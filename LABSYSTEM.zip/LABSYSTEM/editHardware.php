<?php

	session_start();
	$slno = "";

	$labID = $brand  = $hardwaredesc = $makeyear = $warranty = $systemnumber = "";

	$checked="";
	if ($_SERVER["REQUEST_METHOD"] == "GET") {

		$slno = test_input($_GET["slno"]);

	}
	else{

	}

	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}


	//echo "You want to edit ".$slno." with systemCode ";

	require('/database/connection.php');

	$sql = "SELECT * FROM _hardware WHERE `_hardware`.`slno`=".$slno;
	$result = $conn->query($sql);
	//echo $sql;
	if ($result->num_rows > 0) {
	    // output data of each row


	    while($row = $result->fetch_assoc()) {

	    	$labID = $row["labID"];
	    	$hardwaredesc = $row["hardwaredesc"];
	    	$brand = $row["brand"];
	    	$makeyear = $row["makeyear"];
	    	$warranty = $row["warranty"];
	    	if($warranty == "true")$checked="checked";
	    	$compnumber = $row["compnumber"];
	    	//echo $warranty;



	    }
	} else {
	   // echo "0 results";
	}
	$conn->close();
?>



<html>
<head lang="en-US">

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<script>
	function validateForm(){
		return true;
	}

	</script>
</head>

<body>
	<div class="container">
		<div class="row">

			<div class="col-lg-3">
			</div>
			<div class="col-lg-6">
				<form name="edit" action="./Database/hardware/edit.php" onsubmit="return validateForm()" method="post">




					<div class="form-group">
						<lable>Lab name: <?php echo $_SESSION["LABNAME"];?> </lable>
						<input type="hidden" class="form-control" name="labcode" value=<?php echo $labID?> readonly>
					</div>
					<div class="form-group">
						<input type="hidden" class="form-control" name="slno" value=<?php echo $slno?> readonly>
					</div>
					<div class="form-group">
						<lable>Hardware Number:</lable>
						<input type="text" class="form-control" name="compnumber" value='<?php echo $compnumber ?>'>
					</div>
					<div class="form-group">
						<lable>Hardware Description:</lable>
						<input type="text" class="form-control" value=<?php echo $hardwaredesc?> name="hardwaredesc">
					</div>
					<div class="form-group">
						<lable>Brand:</lable>
						<input type="text" class="form-control" value=<?php echo $brand?> name="brand">
					</div>

					<div class="form-group">
						<lable>Make and Year:</lable>
						<input type="text" class="form-control" value=<?php echo $makeyear?> name="makeyear">
					</div>

					<div class="checkbox">
						<lable> <input   type="checkbox" name="warranty"  <?php echo $checked?>>In Warranty:</input></lable>
					</div>
					<a class="btn btn-warning" href="./LabView.php">Cancel</a>
					<input type="submit" class="btn btn-success" value="Submit">
				</form>
			</div>
			<div class="col-lg-3">
			</div>
		</div>
	</div>
</body>
</html>
