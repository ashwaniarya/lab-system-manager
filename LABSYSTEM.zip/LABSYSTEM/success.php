<!DOCTYPE html>
<html>
<head>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons"  rel="stylesheet">
	<style>
	 .maincontainer{
	 	margin-top: 50px;
	 	background-color: #ffffff;
	 	padding-bottom: 20px;
	 }
	</style>
</head>
<body style="background-color: #bcbcbc;background: url(./img/back.png);background-size: cover"> 
	<div class="container maincontainer">
		<div class="row">
			<div class="col-sm-3">
			</div>
			<div class="col-sm-6">
				<img class="img-responsive" src="img/checkmark.gif">
			</div>
			<div class="col-sm-3">
			</div>
		</div>
		<div class="row">
			<div class="col-sm-3">
			</div>
			<div class="col-sm-6">
				
				<center><h3><strong>SUCCESSFULLY INSTALLED<s/trong></h3></center>
				<center><a href="index.php" class="btn btn-success" style="
    height: 50px;
    width: 200px;
    padding-top: 15px;
">Login</a></center>
			</div>
			<div class="col-sm-3">
			</div>
		</div>
	</div>
</body>
</html>