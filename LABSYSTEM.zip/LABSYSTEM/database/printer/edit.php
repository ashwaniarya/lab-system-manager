<?php


	$slno = "";

	$labcode = $brand  = $makeyear = $warranty = $compnumber = "";


	if ($_SERVER["REQUEST_METHOD"] == "POST") {
	 
	  $slno= test_input($_POST["slno"]);
	  $labcode = test_input($_POST["labcode"]);
	
	  $brand  = test_input($_POST["brand"]);
	  $makeyear  = test_input($_POST["makeyear"]);
	  
	  if(!isset($_POST["warranty"])){
	   $warranty  = "false";
	  }
	  else{
	    $warranty  = "true";
	  }

	  $compnumber = test_input($_POST["compnumber"]);

	  
	}

	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}

	require('../connection.php');
	 $s = "','";
	$sql = "UPDATE `_printer` SET `_printer`.`brand` = '".$brand."',`_printer`.`makeyear` = '".$makeyear."',`_printer`.`warranty` = '".$warranty."',`_printer`.`compnumber`='".$compnumber."' WHERE  `_printer`.`slno` = ".$slno." AND `_printer`.`labID` = ".$labcode;

	echo $sql;
	
	if ($conn->query($sql) === TRUE) {
     	echo "{\"status\":true}";

     	header("Location: ../../LabView.php");
     	die();
	} else {
		// echo "Error: " . $sql . "<br>" . $conn->error;
	    echo "{\"status\":false,\"error:\"".$conn->error."}";
	}

  $conn->close();
  
?>

