<?php

	$servername = $username = $password = $uname = $pword = "";

	if($_SERVER["REQUEST_METHOD"] == "POST"){

		$servername = test_input($_POST["servername"]);
		$username = test_input($_POST["username"]);
		$password = test_input($_POST["password"]);
		$uname = test_input($_POST["uname"]);
		$pword = test_input($_POST["pword"]);

		$conn =new mysqli($servername,$username,$password);

		if($conn->connect_error){
			//ECHO CONNECTION ERROR MESSAGE
		}

		$sql = "CREATE DATABASE systemlab";
		if ($conn->query($sql) === TRUE) {
			//Error handling message 
		    echo "<h3>Database created successfully</h3>";
		} else {
		    echo "Error creating database: " . $conn->error;
		}

		$database = "systemlab";
		$conn =new mysqli($servername,$username,$password,$database);

		if($conn->connect_error){
			//ECHO CONNECTION ERROR MESSAGE
		}


		//Create table labs
		$sql = "CREATE TABLE `_labs` (
		  `labID` int(3) NOT NULL PRIMARY KEY AUTO_INCREMENT,
		  `labName` varchar(50) NOT NULL,
		  `pass` varchar(50) NOT NULL
		)";

		if($conn->query($sql) === true){
			echo "<h3>Lab table created successfully</h3>";
		} else {
			echo "Error creating table".$conn->error;
		}

		//Create table hardware
		$sql = "CREATE TABLE `_hardware` (
		  `slno` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
		  `compnumber` varchar(200) DEFAULT NULL,
		  `brand` varchar(200) DEFAULT NULL,
		  `warranty` varchar(10) DEFAULT NULL,
		  `makeyear` varchar(200) DEFAULT NULL,
		  `labID` int(11) DEFAULT NULL,
		  `hardwaredesc` varchar(200) DEFAULT NULL
		)";

		if($conn->query($sql) === true){
			echo "<h3>Hardware table created successfully</h3>";
		} else {
			echo "Error creating table".$conn->error;
		}

		//Create table Maintanance
		$sql = "CREATE TABLE `_maintanance` (
		  `slno` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
		  `particular` varchar(200) DEFAULT NULL,
		  `description` varchar(200) DEFAULT NULL,
		  `warranty` varchar(10) DEFAULT NULL,
		  `_date` date DEFAULT NULL,
		  `breg` varchar(200) DEFAULT NULL,
		  `remarks` varchar(200) DEFAULT NULL,
		  `labID` int(11) DEFAULT NULL
		)";

		if($conn->query($sql) === true){
			echo "<h3>Maintanance table created successfully</h3>";
		} else {
			echo "Error creating table".$conn->error;
		}

		//Create table Notification
		$sql = "CREATE TABLE `_notification` (
		  `_nid` int(3) NOT NULL PRIMARY KEY AUTO_INCREMENT,
		  `_action` varchar(4) NOT NULL,
		  `_status` varchar(10) NOT NULL
		)";

		if($conn->query($sql) === true){
			echo "<h3>Notification table created successfully</h3>";
		} else {
			echo "Error creating table".$conn->error;
		}

		//Create table printer
		$sql = "CREATE TABLE `_printer` (
		  `slno` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
		  `compnumber` varchar(200) DEFAULT NULL,
		  `brand` varchar(200) DEFAULT NULL,
		  `warranty` varchar(10) DEFAULT NULL,
		  `makeyear` varchar(200) DEFAULT NULL,
		  `labID` int(11) DEFAULT NULL
		)";

		if($conn->query($sql) === true){
			echo "<h3>Printer table created successfully</h3>";
		} else {
			echo "Error creating table".$conn->error;
		}

		//Create table system
		$sql = "CREATE TABLE `_system` (
		  `systemID` int(3) NOT NULL PRIMARY KEY AUTO_INCREMENT,
		  `labID` int(3) NOT NULL,
		  `processor_details` varchar(30) DEFAULT NULL,
		  `operating_system` varchar(30) DEFAULT NULL,
		  `ram` varchar(30) DEFAULT NULL,
		  `hdd` varchar(30) DEFAULT NULL,
		  `monitor_size` varchar(30) DEFAULT NULL,
		  `dvd` varchar(30) DEFAULT NULL,
		  `brand` varchar(30) DEFAULT NULL,
		  `make_and_year` varchar(30) DEFAULT NULL,
		  `in_warrent` varchar(30) DEFAULT NULL,
		  `systemCode` varchar(20) DEFAULT 'NOT NULL'
		)";

		if($conn->query($sql) === true){
			echo "<h3>rinter table created successfully</h3>";
		} else {
			echo "Error creating table".$conn->error;
		}


		//Alter table system
		$sql = "ALTER TABLE `_system`
		  ADD UNIQUE KEY `systemCode` (`systemCode`),
		  ADD KEY `labID` (`labID`)";

		if($conn->query($sql) === true){
			echo "<h3>Printer table altered successfully</h3>";
		} else {
			echo "Error creating table".$conn->error;
		}

		//Alter table tempshift
		$sql = "CREATE TABLE `_tempshift` (
		  `slno` int(3) NOT NULL PRIMARY KEY AUTO_INCREMENT,
		  `_nid` int(3) NOT NULL,
		  `systemID` varchar(4) NOT NULL,
		  `labID` int(3) NOT NULL,
		  `_tLabID` int(4) NOT NULL
		)";

		if($conn->query($sql) === true){
			echo "<h3>Tempshift table created successfully</h3>";
		} else {
			echo "Error creating table".$conn->error;
		}

		//Create an init table and admin users table
		$sql = "CREATE TABLE `_users` (
		  `uname` varchar(50) PRIMARY KEY,
		  `pword` varchar(100)
		)";

		if($conn->query($sql) === true){
			echo "<h3>User table created successfully</h3>";
		} else {
			echo "Error creating table".$conn->error;
		}

		
		$sql = "INSERT INTO `_users` VALUES('".$uname."','".$pword."')";

		if($conn->query($sql) === true){
			echo "<h3>Admin user created successfully</h3>";
		} else {
			echo "Error creating table".$conn->error;
		}

		$sql = "CREATE TABLE `_init` (
		  `_install` int(3)
		)";

		if($conn->query($sql) === true){
			echo "<h3>Init table created successfully</h3>";
		} else {
			echo "Error creating table".$conn->error;
		}


		//Create an init table and admin users table
		$sql = "INSERT INTO `_init` VALUES('1')";

		if($conn->query($sql) === true){
			echo "<h3>Web App successfully Installed</h3>";
			header("Location: ../success.php");
		} else {
			echo "Error creating table".$conn->error;
		}
	}


	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}
?>


