<?php

$labID = $sdate = $edate = "";

if ($_SERVER["REQUEST_METHOD"] == "GET") {

  $labID = test_input($_GET["labID"]);
  $sdate = test_input($_GET["sdate"]);
  $edate = test_input($_GET["edate"]);
 
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


require('../connection.php');

  if($sdate == "" && $edate == ""){
     $sql = "SELECT * FROM _maintanance WHERE `labID`=".$labID;
  }else{
    $sql = "SELECT * FROM _maintanance WHERE `labID`=".$labID." AND `_date` BETWEEN '".$sdate."' AND '".$edate."' ";
  }
   
    // $sql = "SELECT * FROM _maintanance WHERE `_date` BETWEEN ".$sdate." AND ".$edate." ";
  

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    $response = "{\"status\":\"true\",\"data\":";
    $data="[";
    while($row = $result->fetch_assoc()) {

        $data = $data."{\"id\":\"".$row["slno"]."\",\"labID\":\"".$row["labID"]."\",\"particular\":\"".$row["particular"]."\",\"description\":\"".$row["description"]."\",\"warranty\":\"".$row["warranty"]."\",\"date\":\"".$row["_date"]."\",\"breg\":\"".$row["breg"]."\",\"remark\":\"".$row["remarks"]."\"},";
       
    }
    $data = substr($data, 0, -1)."]";

    $response = $response.$data."}";

    echo $response;
} else {
   $response = "{\"status\":\"false\",\"data\":\"null\"}";
   echo $response;
}
$conn->close();

?>