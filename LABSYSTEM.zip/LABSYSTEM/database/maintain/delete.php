<?php


	$slno = "";

	if ($_SERVER["REQUEST_METHOD"] == "GET") {

		$slno = test_input($_GET["slno"]);
		require('../connection.php');


		$sql = "DELETE FROM `_maintanance` WHERE `_maintanance`.`slno` = ".$slno;

		if ($conn->query($sql) === TRUE) {
	     	echo "{\"status\":true}";
		} else {
		    echo "{\"status\":false}";
		}

	    $conn->close();
	}
	else{
		
	}

	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}


	
?>