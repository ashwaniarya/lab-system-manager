<?php
require('../connection.php');
// define variables and set to empty values
$labcode = $particular = $description = $date = $warranty = $breg = $remark  = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
 
  $labcode = test_input($_POST["labcode"]);
  $particular  = test_input($_POST["particular"]);
  $description  = test_input($_POST["description"]);

  
  $date  = test_input($_POST["date"]);
  $breg  = test_input($_POST["breg"]);
  
  if(!isset($_POST["warranty"])){
   $warranty  = "false";
  }
  else{
    $warranty  = test_input($_POST["warranty"]);
  }
  $remark = test_input($_POST["remark"]);

  $s = "','";
  $sql = "INSERT INTO `_maintanance`(`labID`, `particular`, `description`, `warranty`, `_date`, `breg`, `remarks`) VALUES ('".$labcode.$s.$particular.$s.$description.$s.$warranty.$s.$date.$s.$breg.$s.$remark."')";
/*
echo "{id:".$id.",labcode:".$labcode.",operating_system:".$operating_system.",ram:".$ram.",hdd:".$hdd.",monitor_size:".$monitor_size.",dvd:".$dvd.",brand:".$brand.",make_and_year:".$make_and_year.",in_warrenty:".$in_warrenty."}";*/
//echo $sql;

  if ($conn->query($sql) === TRUE) {
      echo "New record created successfully";
     header("Location: ../../LabView.php");
     die();
  } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  }
 $labcode = $particular = $description = $date = $warranty = $breg = $remark  = "";
  $conn->close();
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}



?>