<?php

$form = $username = $password = $labID = "";
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {

	$form = test_input($_POST["formname"]);
	echo $form;

	require("connection.php");
	if($form == "adminLogin"){
			$username = test_input($_POST["username"]);
			$password = test_input($_POST["password"]);	
			echo "{username:".$username.",password:".$password."}";

			if($username == "admin" && $password == "admin" ){
				$_SESSION["login"] = true;
				header("Location: ../AdminView.php");
      			die();

			}else{
				$_SESSION["error"]= "Username and Password is not correct";
				header("Location: ../index.php");
      				die();
			}



	}

	if($form == "labLogin"){
			$labID = test_input($_POST["labname"]);
			$password = test_input($_POST["password"]);	
			//echo "{labname:".$labID.",password:".$password."}";


			$sql = "SELECT * FROM _labs WHERE `_labs`.`labID` = '".$labID."' AND `_labs`.`pass` = '".$password."'";
			//echo $sql;
			$result = $conn->query($sql);

			if ($result->num_rows == 1) {
				while($row = $result->fetch_assoc()) {
					$_SESSION["login"] = true;
			   		$_SESSION["LABNAME"]= $row["labName"];
			   		$_SESSION["LABID"] = $row["labID"];

			   		header("Location: ../labView.php");
      		   		die();
				}
			   echo "You can login";
			} else {
			   $_SESSION["error"]= "Password is not correct";
			   header("Location: ../index.php");
      		   die();
			}
	}
	

}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>