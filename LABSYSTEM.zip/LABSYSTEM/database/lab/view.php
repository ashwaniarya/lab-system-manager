<?php
/*
$labID = "";

if ($_SERVER["REQUEST_METHOD"] == "GET") {

	$labID = test_input($_GET["labID"]);

}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

*/
require('../connection.php');

$sql = "SELECT * FROM _labs ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row

    $data="[";
    while($row = $result->fetch_assoc()) {

      $sql2 = "SELECT * FROM `_system` WHERE `_system`.`labID`=".$row["labID"];

      $result2 = $conn->query($sql2);


       $data = $data."{\"id\":\"".$row["labID"]."\",\"labName\":\"".$row["labName"]."\",\"password\":\"".$row["pass"]."\",\"nosystem\":\"".$result2->num_rows."\"},";
       
    }
    $data = substr($data, 0, -1)."]";

    echo $data;
} else {
   // echo "0 results";
}
$conn->close();

?>