<?php


	$labID = "";

	if ($_SERVER["REQUEST_METHOD"] == "GET") {

		$labID = test_input($_GET["labID"]);
		require('../connection.php');

		$sql = "DELETE FROM `_labs` WHERE `_labs`.`labID` = ".$labID;

		if ($conn->query($sql) === TRUE) {
	     	echo "{\"status\":true}";
		} else {
		    echo "{\"status\":false}";
		}

	   $conn->close();


	}
	else{
		
	}

	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}


	
?>