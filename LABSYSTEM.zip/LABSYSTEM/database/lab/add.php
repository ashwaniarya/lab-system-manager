<?php
require('../connection.php');
// define variables and set to empty values
$LabName = $password = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
 
  $LabName = test_input($_POST["labName"]);
  $password  = test_input($_POST["pass"]);
  
  $s = "','";
  $sql = "INSERT INTO `_labs`(`labName`, `pass`) VALUES ('".$LabName.$s.$password."')";

  //echo "{labname:".$LabName.",password:".$password."}";
  //echo $sql;
  //echo $sql;
  /*
  echo "{id:".$id.",labcode:".$labcode.",operating_system:".$operating_system.",ram:".$ram.",hdd:".$hdd.",monitor_size:".$monitor_size.",dvd:".$dvd.",brand:".$brand.",make_and_year:".$make_and_year.",in_warrenty:".$in_warrenty."}";*/
  //echo $sql;

  if ($conn->query($sql) === TRUE) {
      echo "New record created successfully";
     header("Location: ../../AdminView.php");
      die();
  } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  }
  
  $conn->close();
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


?>