<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "systemlab";
// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
	header("location: install.php");
    die("Connection failed: " . $conn->connect_error);

} 
//echo "Connected successfully";
?>