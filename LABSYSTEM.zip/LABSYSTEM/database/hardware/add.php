<?php
require('../connection.php');
// define variables and set to empty values
$labcode = $hardwaredesc = $brand  = $make_and_year = $in_warrenty = $compnumber = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
 
  $labcode = test_input($_POST["labcode"]);
  $brand  = test_input($_POST["brand"]);
  $make_and_year  = test_input($_POST["make_and_year"]);
  $hardwaredesc = test_input($_POST["hardwaredesc"]);
  
  if(!isset($_POST["in_warrenty"])){
   $in_warrenty  = "false";
  }
  else{
    $in_warrenty  = test_input($_POST["in_warrenty"]);
  }
  $compnumber = test_input($_POST["compnumber"]);
  $s = "','";
  $sql = "INSERT INTO `_hardware`(`labID`, `hardwaredesc`,`brand`, `makeyear`, `warranty`,`compnumber`) VALUES ('".$labcode.$s.$hardwaredesc.$s.$brand.$s.$make_and_year.$s.$in_warrenty.$s.$compnumber."')";
/*
echo "{id:".$id.",labcode:".$labcode.",operating_system:".$operating_system.",ram:".$ram.",hdd:".$hdd.",monitor_size:".$monitor_size.",dvd:".$dvd.",brand:".$brand.",make_and_year:".$make_and_year.",in_warrenty:".$in_warrenty."}";*/
//echo $sql;

  if ($conn->query($sql) === TRUE) {
      echo "New record created successfully";
      header("Location: ../../LabView.php");
      die();
  } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  }
 
  $conn->close();
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}



?>