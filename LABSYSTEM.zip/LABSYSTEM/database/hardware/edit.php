<?php


	$slno = "";

	$labcode = $hardwaredesc = $brand  = $makeyear = $warranty = $compnumber = "";


	if ($_SERVER["REQUEST_METHOD"] == "POST") {
	 
	  $slno= test_input($_POST["slno"]);
	  $labcode = test_input($_POST["labcode"]);
	  $hardwaredesc = test_input($_POST["hardwaredesc"]);
	  $brand  = test_input($_POST["brand"]);
	  $makeyear  = test_input($_POST["makeyear"]);

	  
	  if(!isset($_POST["warranty"])){
	   $warranty  = "false";
	  }
	  else{
	    $warranty  = "true";
	  }

	  $compnumber = test_input($_POST["compnumber"]);

	  
	}

	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}

	require('../connection.php');
	 $s = "','";
	$sql = "UPDATE `_hardware` SET `_hardware`.`brand` = '".$brand."',`_hardware`.`hardwaredesc` = '".$hardwaredesc."',`_hardware`.`makeyear` = '".$makeyear."',`_hardware`.`warranty` = '".$warranty."',`_hardware`.`compnumber`='".$compnumber."' WHERE  `_hardware`.`slno` = ".$slno." AND `_hardware`.`labID` = ".$labcode;

	echo $sql;
	
	if ($conn->query($sql) === TRUE) {
     	echo "{\"status\":true}";

     	header("Location: ../../LabView.php");
     	die();
	} else {
		// echo "Error: " . $sql . "<br>" . $conn->error;
	    echo "{\"status\":false,\"error:\"".$conn->error."}";
	}

  $conn->close();
  
?>

