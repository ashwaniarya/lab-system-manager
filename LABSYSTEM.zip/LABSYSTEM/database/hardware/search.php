<?php

$labID = $compnumber = "";

if ($_SERVER["REQUEST_METHOD"] == "GET") {

  $labID = test_input($_GET["labID"]);
  $compnumber = test_input($_GET["compnumber"]);


}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


require('../connection.php');

 if($compnumber == "987654321"){
    $sql = "SELECT * FROM _hardware WHERE `labID`=".$labID;
  }else{
    $sql = "SELECT * FROM _hardware WHERE `labID`=".$labID." AND `compnumber`LIKE '%".$compnumber."%'";
  }

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    $response = "{\"status\":\"true\",\"data\":";
    $data="[";
    while($row = $result->fetch_assoc()) {

        $data = $data."{\"id\":\"".$row["slno"]."\",\"labID\":\"".$row["labID"]."\",\"compnumber\":\"".$row["compnumber"]."\",\"hardwaredesc\":\"".$row["hardwaredesc"]."\",\"brand\":\"".$row["brand"]."\",\"warranty\":\"".$row["warranty"]."\",\"makeyear\":\"".$row["makeyear"]."\"},";
       
    }
    $data = substr($data, 0, -1)."]";

    $response = $response.$data."}";

    echo $response;
} else {
   $response = "{\"status\":\"false\",\"data\":\"null\"}";
   echo $response;
}
$conn->close();

?>