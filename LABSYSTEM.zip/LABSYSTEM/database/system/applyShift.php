<?php

$nid = "";

if ($_SERVER["REQUEST_METHOD"] == "GET") {

  $nid = test_input($_GET["nid"]);

  require('../connection.php');

  $sql = "SELECT * FROM _tempshift WHERE `_nid`=".$nid;
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
      // output data of each row

      
      while($row = $result->fetch_assoc()) {

        $sql2= "UPDATE _system SET `labID`=".$row["labID"]." WHERE `systemID`=".$row["systemID"];

        if($conn->query($sql2) === TRUE){

         

           $sql3= "UPDATE _notification SET `_status`='accepted' WHERE `_nid`=".$nid;
            if($conn->query($sql3) === TRUE){
               
            }
        }
      }

      echo "{\"status\":\"true\"}";
      
  } else {
     echo "{\"status\":\"false\"}";
  }
  $conn->close();

}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}




?>