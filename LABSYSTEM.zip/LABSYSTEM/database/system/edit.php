<?php


	$SystemID = "";

	$labcode = $processor_details = $operating_system = $ram = $hdd = $monitor_size= $dvd = $brand  = $make_and_year = $in_warrenty = $systecode = "";


	if ($_SERVER["REQUEST_METHOD"] == "POST") {
	 
	  $systemID= test_input($_POST["systemID"]);
	  $labcode = test_input($_POST["labcode"]);
	  $processor_details  = test_input($_POST["processor_details"]);
	  $operating_system  = test_input($_POST["operating_system"]);
	  $ram  = test_input($_POST["ram"]);
	  $hdd  = test_input($_POST["hdd"]);
	  $monitor_size  = test_input($_POST["monitor_size"]);

	  if(!isset($_POST["dvd"])){
	    $dvd = "false";
	  }
	  else{
	    $dvd  = test_input($_POST["dvd"]);
	  }
	  
	  $brand  = test_input($_POST["brand"]);
	  $make_and_year  = test_input($_POST["make_and_year"]);
	  
	  if(!isset($_POST["in_warrenty"])){
	   $in_warrenty  = "false";
	  }
	  else{
	    $in_warrenty  = test_input($_POST["in_warrenty"]);
	  }

	  $systecode = test_input($_POST["systecode"]);

	  echo $dvd;
	}

	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}

	require('../connection.php');
	 $s = "','";
	$sql = "UPDATE `_system` SET `_system`.`processor_details` = '".$processor_details."',`_system`.`operating_system` = '".$operating_system."',`_system`.`ram` = '".$ram."',`_system`.`hdd` = '".$hdd."',`_system`.`monitor_size` = '".$monitor_size."',`_system`.`dvd` = '".$dvd."',`_system`.`brand` = '".$brand."',`_system`.`make_and_year` = '".$make_and_year."',`_system`.`in_warrent` = '".$in_warrenty."',`_system`.`systemCode`='".$systecode."' WHERE  `_system`.`systemID` = ".$systemID." AND `_system`.`labID` = ".$labcode;

	
	
	if ($conn->query($sql) === TRUE) {
     	echo "{\"status\":true}";

     	header("Location: ../../LabView.php");
     	die();
	} else {
		// echo "Error: " . $sql . "<br>" . $conn->error;
	    echo "{\"status\":false,\"error:\"".$conn->error."}";
	}

  $conn->close();
  
?>

