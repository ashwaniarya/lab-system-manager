<?php


	$SystemID = "";

	if ($_SERVER["REQUEST_METHOD"] == "GET") {

		$SystemID = test_input($_GET["systemID"]);
		require('../connection.php');
	}
	else{
		
	}

	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}


	$sql = "DELETE FROM `_system` WHERE `_system`.`systemID` = ".$SystemID;

	if ($conn->query($sql) === TRUE) {
     	echo "{\"status\":true}";
	} else {
	    echo "{\"status\":false}";
	}

  $conn->close();
?>