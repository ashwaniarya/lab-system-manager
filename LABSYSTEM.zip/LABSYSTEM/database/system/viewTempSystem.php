<?php

$nid = "";
$action ="";
if ($_SERVER["REQUEST_METHOD"] == "GET") {

	$action = test_input($_GET["action"]);
	$nid = test_input($_GET["nid"]);



  if($action == "list"){
    require('../connection.php');

    $sql = "SELECT * FROM _tempshift WHERE `_nid`=".$nid;

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
         $response = "{\"status\":\"true\",\"noOfSystem\":\"".$result->num_rows."\",\"data\":";
        $data="[";
        while($row = $result->fetch_assoc()) {

           $data = $data."{\"nid\":\"".$row["_nid"]."\",\"from\":\"".$row["_tLabID"]."\",\"to\":\"".$row["labID"]."\"},";
           
        }
        $data = substr($data, 0, -1)."]";

       

        $response = $response.$data."}";

        echo $response;
    } else {
      $response = "{\"status\":\"false\",\"noOfSystem\":\"0\",\"data\":\"null\"}";
      echo $response;
    }
    $conn->close();
  }

}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>