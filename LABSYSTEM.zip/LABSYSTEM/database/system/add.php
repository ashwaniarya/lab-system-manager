<?php
require('../connection.php');
// define variables and set to empty values
$labcode = $processor_details = $operating_system = $ram = $hdd = $monitor_size= $dvd = $brand  = $make_and_year = $in_warrenty = $systemcode = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
 
  $labcode = test_input($_POST["labcode"]);
  $processor_details  = test_input($_POST["processor_details"]);
  $operating_system  = test_input($_POST["operating_system"]);
  $ram  = test_input($_POST["ram"]);
  $hdd  = test_input($_POST["hdd"]);
  $monitor_size  = test_input($_POST["monitor_size"]);
  if(!isset($_POST["dvd"])){
    $dvd = "false";
  }
  else{
    $dvd  = test_input($_POST["dvd"]);
  }
  
  $brand  = test_input($_POST["brand"]);
  $make_and_year  = test_input($_POST["make_and_year"]);
  
  if(!isset($_POST["in_warrenty"])){
   $in_warrenty  = "false";
  }
  else{
    $in_warrenty  = test_input($_POST["in_warrenty"]);
  }
  $systemcode = test_input($_POST["systemcode"]);
  $s = "','";
  $sql = "INSERT INTO `_system`(`labID`, `processor_details`, `operating_system`, `ram`, `hdd`, `monitor_size`, `dvd`, `brand`, `make_and_year`, `in_warrent`,`systemCode`) VALUES ('".$labcode.$s.$processor_details.$s.$operating_system.$s.$ram.$s.$hdd.$s.$monitor_size.$s.$dvd.$s.$brand.$s.$make_and_year.$s.$in_warrenty.$s.$systemcode."')";
/*
echo "{id:".$id.",labcode:".$labcode.",operating_system:".$operating_system.",ram:".$ram.",hdd:".$hdd.",monitor_size:".$monitor_size.",dvd:".$dvd.",brand:".$brand.",make_and_year:".$make_and_year.",in_warrenty:".$in_warrenty."}";*/
//echo $sql;

  if ($conn->query($sql) === TRUE) {
      echo "New record created successfully";
      header("Location: ../../LabView.php");
      die();
  } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  }
  $labcode = $processor_details = $operating_system = $ram = $hdd = $monitor_size= $dvd = $brand  = $make_and_year = $in_warrenty = $systemcode = "";
  $conn->close();
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}



?>