<?php
require('../connection.php');
// define variables and set to empty values
$nid = $systemID = $labID = $tlabID="";


if ($_SERVER["REQUEST_METHOD"] == "GET") {
 
  $nid = test_input($_GET["nid"]);
  $systemID = test_input($_GET["systemID"]);
  $labID  = test_input($_GET["labID"]);
  $tlabID  = test_input($_GET["tlabID"]);


 $sql = "INSERT INTO `_tempshift`(`_nid`, `systemID`,`labID`,`_tLabID`) VALUES ('". $nid."','".$systemID."','".$labID."','".$tlabID."')";

  if ($conn->query($sql) === TRUE) {
    echo "{\"status\":\"true\"}";

  }
   else {
    echo "{\"status\":\"false\"}";
  }


  $conn->close();
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


?>