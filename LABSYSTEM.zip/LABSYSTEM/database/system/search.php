<?php

$labID = $systemcode = "";

if ($_SERVER["REQUEST_METHOD"] == "GET") {

  $labID = test_input($_GET["labID"]);
  $systemcode = test_input($_GET["systemcode"]);


}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


require('../connection.php');

 if($systemcode == "987654321"){
    $sql = "SELECT * FROM _system WHERE `labID`=".$labID;
  }else{
    $sql = "SELECT * FROM _system WHERE `labID`=".$labID." AND `systemcode` LIKE '%".$systemcode."%'";
  }

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    $response = "{\"status\":\"true\",\"data\":";
    $data="[";
    while($row = $result->fetch_assoc()) {

        $data = $data."{\"id\":\"".$row["systemID"]."\",\"labID\":\"".$row["labID"]."\",\"operating_system\":\"".$row["operating_system"]."\",\"ram\":\"".$row["ram"]."\",\"hdd\":\"".$row["hdd"]."\",\"monitor_size\":\"".$row["monitor_size"]."\",\"dvd\":\"".$row["dvd"]."\",\"brand\":\"".$row["brand"]."\",\"make_and_year\":\"".$row["make_and_year"]."\",\"in_warrenty\":\"".$row["in_warrent"]."\",\"systemcode\":\"".$row["systemCode"]."\",\"processor_details\":\"".$row["processor_details"]."\"},";
       
    }
    $data = substr($data, 0, -1)."]";

    $response = $response.$data."}";

    echo $response;
} else {
   $response = "{\"status\":\"false\",\"data\":\"null\"}";
   echo $response;
}
$conn->close();

?>