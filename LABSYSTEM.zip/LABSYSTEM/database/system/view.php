<?php

$labID = "";

if ($_SERVER["REQUEST_METHOD"] == "GET") {

	$labID = test_input($_GET["labID"]);

}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


require('../connection.php');

$sql = "SELECT * FROM _system WHERE `labID`=".$labID;
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row

    $data="[";
    while($row = $result->fetch_assoc()) {

       $data = $data."{\"id\":\"".$row["systemID"]."\",\"labID\":\"".$row["labID"]."\",\"operating_system\":\"".$row["operating_system"]."\",\"ram\":\"".$row["ram"]."\",\"hdd\":\"".$row["hdd"]."\",\"monitor_size\":\"".$row["monitor_size"]."\",\"dvd\":\"".$row["dvd"]."\",\"brand\":\"".$row["brand"]."\",\"make_and_year\":\"".$row["make_and_year"]."\",\"in_warrenty\":\"".$row["in_warrent"]."\",\"systemcode\":\"".$row["systemCode"]."\",\"processor_details\":\"".$row["processor_details"]."\"},";
       
    }
    $data = substr($data, 0, -1)."]";

    echo $data;
} else {
   //echo "{\"status\":\"null\"}";
}
$conn->close();

?>