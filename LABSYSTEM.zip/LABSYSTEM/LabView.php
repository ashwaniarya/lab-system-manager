<?php

		session_start();



	//echo $_SESSION["login"];

		if(!isset($_SESSION["login"])){
			if(!$_SESSION["login"]){


				session_destroy();
				header("Location: ./index.php");
		      	die();
			}
		}
		if(isset($_SESSION["LABNAME"]) && isset($_SESSION["LABID"])){

	 				if($_SESSION["LABNAME"] == "" && $_SESSION["LABID"]== ""){
					    $_SESSION["error"] = "INVALID";
	 					header("Location: ../index.php");
      		   			die();

		    		}
		}
		else
		{
				$_SESSION["error"] = "INVALID";
				header("Location: ../index.php");
      		   	die();
		}
?>


<!DOCTYPE html>
<html>
<head lang="en-US">

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons"  rel="stylesheet">
	 <link rel="stylesheet" href="css/st.css">
	<script>
	var currentTab="system";
	function validateForm(){
		return true;
	}
	$( document ).ready(()=>{
		OnClickSystem();
		populateSystemList();
		populateLabList();
		populatePrinterList(987654321);
		populateHardwareList(987654321);
		console.log($( document ).height());
		$(".fixHeight").outerHeight($(" body" ).outerHeight());


	});

	$(window).ready(()=>{
		//$("#formContainer").hide();
		$("#actionContainerClose").hide();
	});

	function populateSystemList(){

		var target = '<?php echo $_SESSION["LABID"]; ?>';
		fetch('./Database/system/view?labID='+target)
		  .then(
		    function(response) {
		      if (response.status !== 200) {
		        console.log('Looks like there was a problem. Status Code: ' +
		          response.status);
		        return;
		      }

		      // Examine the text in the response
		      response.json().then((data)=>{

		      	console.log(data);
		      	data.forEach((item,index)=>{
		      		var element = "<tr class='listSystem'><td><input type='checkbox' onchange=actionHandler("+item.id+") ></input></td><td>"+(index+1)+".</td><td>"+item.systemcode+"</td><td>"+item.operating_system+"</td><td>"+item.processor_details+"</td><td>"+(item.ram)+"</td><td>"+(item.hdd)+"</td><td>"+(item.monitor_size)+"</td><td>"+(item.dvd=='true'?'Yes':'No')+"</td><td>"+(item.brand)+"</td><td>"+(item.make_and_year)+"</td><td>"+(item.in_warrenty=='true'?'Yes':'No')+"</td><td><a href='editSystem?systemID="+item.id+"' type='button' class='btn btn-warning btn-block' ><span class='glyphicon glyphicon-edit'></span></a></td><td><button type='button' class='btn btn-danger '  onClick=deleteItem("+item.id+",'system')><span class='glyphicon glyphicon-trash'></span></button></td></tr>";

		      		//var element = "<div  class='list-group-item card list'><input type='checkbox' onchange=actionHandler("+item.id+") ></input><div class='slno'>"+(index+1)+".</div><div class='info' >"+item.systemcode+" | "+item.operating_system+"</div><a href='editSystem?systemID="+item.id+"' type='button' class='btn btn-warning edit' ><span class='glyphicon glyphicon-edit'></span></a><button type='button' class='btn btn-danger delete'  onClick=deleteItem("+item.id+")><span class='glyphicon glyphicon-trash'></span></button></div>";

		      		$('#SystemListContainer').append(element);
		      	});
		      });
		    }
		  )
		  .catch(function(err) {
		    console.log('Fetch Error :-S', err);
		  });
	}

	function populatePrinterList(key){

		var target = '<?php echo $_SESSION["LABID"]; ?>';
		fetch('./Database/printer/search?labID='+target+'&compnumber='+key)
		  .then(
		    function(response) {
		      if (response.status !== 200) {
		        console.log('Looks like there was a problem. Status Code: ' +
		          response.status);
		        return;
		      }

		      // Examine the text in the response
		      response.json().then((val)=>{
		      	clearPrinter();
		      	console.log(val);
		      	if(val.status === "true"){
		      		data = val.data;

		      		data.forEach((item,index)=>{


		      			var element = "<tr class='listPrinter'><td></td><td>"+(index+1)+".</td><td>"+item.compnumber+"</td><td>"+(item.brand)+"</td><td>"+(item.makeyear)+"</td><td>"+(item.warranty=='true'?'Yes':'No')+"</td><td><a href='editPrinter?slno="+item.id+"' type='button' class='btn btn-warning btn-block' ><span class='glyphicon glyphicon-edit'></span></a></td><td><button type='button' class='btn btn-danger '  onClick=deleteItem("+item.id+",'printer')><span class='glyphicon glyphicon-trash'></span></button></td></tr>";
		      		//var element = "<div  class='list-group-item card list'><input type='checkbox' onchange=actionHandler("+item.id+") ></input><div class='slno'>"+(index+1)+".</div><div class='info' >"+item.systemcode+" | "+item.operating_system+"</div><a href='editSystem?systemID="+item.id+"' type='button' class='btn btn-warning edit' ><span class='glyphicon glyphicon-edit'></span></a><button type='button' class='btn btn-danger delete'  onClick=deleteItem("+item.id+")><span class='glyphicon glyphicon-trash'></span></button></div>";
		      		$('#PrinterListContainer').append(element);

		      	});
		      	}
		      	else{
		      		clearPrinter();
		      	}

		      });
		    }
		  )
		  .catch(function(err) {
		    console.log('Fetch Error :-S', err);
		  });
	}
	function populateHardwareList(key){

		var target = '<?php echo $_SESSION["LABID"]; ?>';
		fetch('./Database/hardware/search?labID='+target+'&compnumber='+key)
		  .then(
		    function(response) {
		      if (response.status !== 200) {
		        console.log('Looks like there was a problem. Status Code: ' +
		          response.status);
		        return;
		      }

		      // Examine the text in the response
		      response.json().then((val)=>{

		      	clearHardware();
		      	console.log(val);
		      	if(val.status === "true"){
		      		data = val.data;

		      		data.forEach((item,index)=>{


		      		var element = "<tr class='listHardware'><td></td><td>"+(index+1)+".</td><td>"+item.compnumber+"</td><td>"+item.hardwaredesc+"</td><td>"+(item.brand)+"</td><td>"+(item.makeyear)+"</td><td>"+(item.warranty=='true'?'Yes':'No')+"</td><td><a href='editHardware?slno="+item.id+"' type='button' class='btn btn-warning btn-block' ><span class='glyphicon glyphicon-edit'></span></a></td><td><button type='button' class='btn btn-danger '  onClick=deleteItem("+item.id+",'hardware')><span class='glyphicon glyphicon-trash'></span></button></td></tr>";
		      		//var element = "<div  class='list-group-item card list'><input type='checkbox' onchange=actionHandler("+item.id+") ></input><div class='slno'>"+(index+1)+".</div><div class='info' >"+item.systemcode+" | "+item.operating_system+"</div><a href='editSystem?systemID="+item.id+"' type='button' class='btn btn-warning edit' ><span class='glyphicon glyphicon-edit'></span></a><button type='button' class='btn btn-danger delete'  onClick=deleteItem("+item.id+")><span class='glyphicon glyphicon-trash'></span></button></div>";
		      		$('#HardwareListContainer').append(element);

		      	});
		      	}
		      	else{

		      		clearHardware();
		      	}

		      });
		    }
		  )
		  .catch(function(err) {
		    console.log('Fetch Error :-S', err);
		  });
	}

	var selectedId=[];
	function actionHandler(id){


		var exist = false;
		var indexT=0;

		 selectedId.forEach((item,index)=>{
			//console.log(index+"--"+item);
			if(item == id){
				exist = true;
				indexT = index;
			}
		});

		if(exist){
			console.log("Deleting");
			delete  selectedId[indexT];
		}
		else{
			console.log("Adding");
			 selectedId.push(id);
		}

		var newSelectedId=[];
		console.log("You have selected");
		 selectedId.forEach((item,index)=>{
		 	newSelectedId.push(item);
			console.log(index+"--"+item);
		});

		 selectedId = newSelectedId;
	}

	function shiftAction(){
		var count=0;
		selectedId.forEach((item,index)=>{
			count++;
		});

		$("#shiftModelAction").html("Shift "+count+" system to");
		$("#myModal").modal();
	}

	function requestShift(){
		AJAXCreateNoti();
	}

	function AJAXCreateNoti(){

		fetch('./Database/system/addNotification?action=addnoti')
		  .then(
		    function(response) {
		      if (response.status !== 200) {
		        console.log('Looks like there was a problem. Status Code: ' +
		          response.status);
		        return;
		      }

		      // Examine the text in the response

		      response.json().then((data)=>{
		      	console.log(data);
		      	var generatedNid = data.nid;

			    selectedId.forEach((item,index)=>{
					var labid = $("#LabListContainer").val();
					var target = '<?php echo $_SESSION["LABID"]; ?>';
					console.log("NID:"+generatedNid+",SYSTEMID:"+item+",TO LABID:"+labid+",FROM LABID:"+target);
				 	AJAXcallForShift(generatedNid,item,labid,target);
				});
				location.reload();

		      });
		    }
		  )
		  .catch(function(err) {
		    console.log('Fetch Error :-S', err);
		  });


	}
	function AJAXcallForShift(nid,systemID,labId,tLabId){
		fetch('./Database/system/shift?nid='+nid+'&systemID='+systemID+'&labID='+labId+'&tlabID='+tLabId)
		  .then(
		    function(response) {
		      if (response.status !== 200) {
		        console.log('Looks like there was a problem. Status Code: ' +
		          response.status);
		        return;
		      }

		      // Examine the text in the response
		      response.json().then((data)=>{
		      	if(data.status === 'true'){
		      		console.log("New System add for nid "+nid);
		      	}
		      	else{

		      	}
		      });
		    }
		  )
		  .catch(function(err) {
		    console.log('Fetch Error :-S', err);
		  });
	}

	function warning(item){
		$("#warningDesc").html("Are you sure you want to delete this "+item+" ?");
		$("#myModalDelete").modal();
	}


	function deleteItem(id,item){
		console.log("Deleting : "+id);
		warning(item);
		$("#applyDelete").on("click",()=>{serverCallDelete(id,item);});

	}

	function serverCallDelete(id,item){
		if(item === "system"){
			fetch('./Database/system/delete?systemID='+id)
			  .then(
			    function(response) {
			      if (response.status !== 200) {
			        console.log('Looks like there was a problem. Status Code: ' +
			          response.status);
			        return;
			      }

			      // Examine the text in the response
			      response.json().then((data)=>{
			      	console.log(data);
			      	if(data.status === true){
			      		$("#myModalDelete").modal("hide");
			      		populateSystemListWhenSearched(987654321);
			      	}
			      });
			    }
			  )
			  .catch(function(err) {
			    console.log('Fetch Error :-S', err);
			  });
		}
		if(item === "printer"){
			fetch('./Database/printer/delete?slno='+id)
			  .then(
			    function(response) {
			      if (response.status !== 200) {
			        console.log('Looks like there was a problem. Status Code: ' +
			          response.status);
			        return;
			      }

			      // Examine the text in the response
			      response.json().then((data)=>{
			      	console.log(data);
			      	if(data.status === true){
			      		$("#myModalDelete").modal("hide");
			      		populatePrinterList(987654321);
			      	}
			      });
			    }
			  )
			  .catch(function(err) {
			    console.log('Fetch Error :-S', err);
			  });
		}
		if(item === "hardware"){
			fetch('./Database/hardware/delete?slno='+id)
			  .then(
			    function(response) {
			      if (response.status !== 200) {
			        console.log('Looks like there was a problem. Status Code: ' +
			          response.status);
			        return;
			      }

			      // Examine the text in the response
			      response.json().then((data)=>{
			      	console.log(data);
			      	if(data.status === true){
			      		$("#myModalDelete").modal("hide");
			      		populateHardwareList(987654321);
			      	}
			      });
			    }
			  )
			  .catch(function(err) {
			    console.log('Fetch Error :-S', err);
			  });
		}
		if(item === "maintanance"){

			fetch('./Database/maintain/delete?slno='+id)
			  .then(
			    function(response) {
			      if (response.status !== 200) {
			        console.log('Looks like there was a problem. Status Code: ' +
			          response.status);
			        return;
			      }

			      // Examine the text in the response
			      response.json().then((data)=>{
			      	console.log(data);
			      	if(data.status === true){
			      		$("#myModalDelete").modal("hide");
			      		findMaintananceRecord();
			      	}
			      });
			    }
			  )
			  .catch(function(err) {
			    console.log('Fetch Error :-S', err);
			  });
		}
	}


	function animateCustom(val){
		var targetheight = $(".main").css("height");


		var value = "translateY(-"+(targetheight)+")";
		console.log("#formContainer"+currentTab);
		if(val){

			$("#formContainer"+currentTab).show();
			$("#actionContainerClose").show();
			$("#addForm"+currentTab).css("transform",value).css("position","absolute").css("opacity","1").css("z-index","120");

		}
		else{

			$("#addForm"+currentTab).css("transform","translateY(0px)").css("position","fixed").css("opacity","0");
			//$("#formContainer").hide();
			$("#actionContainerClose").hide();

		}

	}

	function validateForm(){
		return true;
	}
	function search(){
		var item = currentTab;
		var val = $("#search-bar"+item).val();
		if(val === "")val = "987654321";
		if(item === "system"){
			populateSystemListWhenSearched(val);
		}
		if(item === "printer"){
			populatePrinterList(val);
		}
		if(item === "hardware"){
			populateHardwareList(val);
		}


	}
	function clear(){

			$(".listSystem").remove();

	}

	function clearPrinter(){
			$(".listPrinter").remove();

	}

	function clearHardware(){
		$(".listHardware").remove();

	}
		function clearMaintanance(){
		$(".listMaintanance").remove();

	}

	function populateSystemListWhenSearched(key){

		var target = '<?php echo $_SESSION["LABID"]; ?>';
		fetch('./Database/system/search?labID='+target+'&systemcode='+key)
		  .then(
		    function(response) {
		      if (response.status !== 200) {
		        console.log('Looks like there was a problem. Status Code: ' +
		          response.status);
		        return;
		      }
		      //console.log(response);
		      // Examine the text in the response
		      response.json().then((val)=>{
		      	clear();
		      	console.log(val);
		      	if(val.status === "true"){
		      		data = val.data;

		      		data.forEach((item,index)=>{


		      			var element = "<tr class='listSystem'><td><input type='checkbox' onchange=actionHandler("+item.id+") ></input></td><td>"+(index+1)+".</td><td>"+item.systemcode+"</td><td>"+item.operating_system+"</td><td>"+item.processor_details+"</td><td>"+(item.ram)+"</td><td>"+(item.hdd)+"</td><td>"+(item.monitor_size)+"</td><td>"+(item.dvd=='true'?'Yes':'No')+"</td><td>"+(item.brand)+"</td><td>"+(item.make_and_year)+"</td><td>"+(item.in_warrenty=='true'?'Yes':'No')+"</td><td><a href='editSystem?systemID="+item.id+"' type='button' class='btn btn-warning btn-block' ><span class='glyphicon glyphicon-edit'></span></a></td><td><button type='button' class='btn btn-danger '  onClick=deleteItem("+item.id+",'system')><span class='glyphicon glyphicon-trash'></span></button></td></tr>";
		      		//var element = "<div  class='list-group-item card list'><input type='checkbox' onchange=actionHandler("+item.id+") ></input><div class='slno'>"+(index+1)+".</div><div class='info' >"+item.systemcode+" | "+item.operating_system+"</div><a href='editSystem?systemID="+item.id+"' type='button' class='btn btn-warning edit' ><span class='glyphicon glyphicon-edit'></span></a><button type='button' class='btn btn-danger delete'  onClick=deleteItem("+item.id+")><span class='glyphicon glyphicon-trash'></span></button></div>";

		      		$('#SystemListContainer').append(element);
		      	});
		      	}
		      	else{
		      		clear();
		      	}

		      });
		    }
		  )
		  .catch(function(err) {
		    console.log('Fetch Error :-S', err);
		  });
	}


	 function populateLabList(){
	 	fetch('./Database/lab/view')
		  .then(
		    function(response) {
		      if (response.status !== 200) {
		        console.log('Looks like there was a problem. Status Code: ' +
		          response.status);
		        return;
		      }

		      // Examine the text in the response
		      response.json().then((data)=>{


		      	data.forEach((item,index)=>{
		      		//var element = "<div  class='list-group-item card'><div class='slno'>"+(index+1)+".</div><div class='info' onClick=populateSystemList("+item.id+")>"+item.labName+"</div><a href='editSystem?systemID="+item.id+"' type='button' class='btn btn-warning edit' ><span class='glyphicon glyphicon-edit'></span></a><button type='button' class='btn btn-danger delete'  onClick=deleteLabItem("+item.id+")><span class='glyphicon glyphicon-trash'></span></button></div>";

		      		var element = "<option class='form-control' value='"+item.id+"'>"+item.labName+"</option>";

		      		$('#LabListContainer').append(element);
		      	});
		      });
		    }
		  )
		  .catch(function(err) {
		    console.log('Fetch Error :-S', err);
		  });
	 }

	 function OnClickSystem(){
	 	currentTab = "system";
	 	removeClass();
	 	$("#system").addClass("active");
	 	$(".system").css("display","");
	 	$(".maintanace").css("display","none");
	 	$(".printer").css("display","none");
	 	$(".hardware").css("display","none");

	 }
	  function OnClickPrinter(){
	  	currentTab = "printer";
	  	removeClass();
	 	$("#printer").addClass("active");
	 	$(".system").css("display","none");
	 	$(".maintanace").css("display","none");
	 	$(".printer").css("display","");
	 	$(".hardware").css("display","none");

	 }
	  function OnClickHardware(){
	  	currentTab = "hardware";
	  	removeClass();
	 	$("#hardware").addClass("active");
	 	$(".system").css("display","none");
	 	$(".maintanace").css("display","none");
	 	$(".printer").css("display","none");
	 	$(".hardware").css("display","");

	 }
	 function OnClickMaintanance(){
	 	currentTab = "maintanace";
	 	removeClass();
	 	$("#maintanace").addClass("active");
	 	$(".system").css("display","none");
	 	$(".maintanace").css("display","");
	 	$(".printer").css("display","none");
	 	$(".hardware").css("display","none");
	 }
	 function removeClass(){
	 	$(".navitem").removeClass("active");
	 }

	 function findMaintananceRecord(){
	 	var fromDate = $("#fromDate").val();
	 	var toDate = $("#toDate").val();
	 	var target = '<?php echo $_SESSION["LABID"]; ?>';
	 	var hitpoint = "./Database/maintain/search?labID="+target+"&sdate="+fromDate+"&edate="+toDate;
	 	console.log(hitpoint);
	 	fetch(hitpoint)
	 		.then((response)=>{
	 			if(response.status !== 200){
	 			  console.log('Looks like there was a problem. Status Code: ' +
		          response.status);
		          return;
	 			}
	 			//console.log(response);
	 			  response.json().then((val)=>{
		      	clearMaintanance();
		      	//console.log(val);
		      	if(val.status === "true"){
		      		data = val.data;

		      		data.forEach((item,index)=>{


		      			var element = "<tr class='listMaintanance'><td>"+(index+1)+".</td><td>"+item.particular+"</td><td>"+item.description+"</td><td>"+(item.in_warrenty=='true'?'Yes':'No')+"</td><td>"+item.date+"</td><td>"+(item.breg)+"</td><td>"+(item.remark)+"</td><td><button type='button' class='btn btn-danger '  onClick=deleteItem("+item.id+",'maintanance')><span class='glyphicon glyphicon-trash'></span></button></td></tr>";
		      		//var element = "<div  class='list-group-item card list'><input type='checkbox' onchange=actionHandler("+item.id+") ></input><div class='slno'>"+(index+1)+".</div><div class='info' >"+item.systemcode+" | "+item.operating_system+"</div><a href='editSystem?systemID="+item.id+"' type='button' class='btn btn-warning edit' ><span class='glyphicon glyphicon-edit'></span></a><button type='button' class='btn btn-danger delete'  onClick=deleteItem("+item.id+")><span class='glyphicon glyphicon-trash'></span></button></div>";

		      		$('#MaintainListContainer').append(element);
		      	});
		      	}
		      	else{
		      		clearMaintanance();
		      	}

		      });


	 		})
	 		.catch(function(err) {
		    console.log('Fetch Error :-S', err);
		  });
	 }
	</script>
	<style>
		.main{
			min-height: 500px;
			background-color: #f1f1f1;
		    padding-left: 0px;
		    padding-right: 0px;
		    padding-top: 0px;
		    padding-bottom: 20px;
		    margin-top: 20px;
		    margin-bottom: 20px;
		    box-shadow: 0 4px 4px #9b9b9b;
		    display: flex;
		    flex-direction: column;
		}
		#actionContainer{
			display: flex;
			align-items: center;
			justify-content: space-around;
			position: fixed;
			z-index: 50;
		    position: fixed;
		    top: 80%;
		    left: 85%;
		}
		#actionButton{
			height: 80px;
		    width: 80px;
		    border-radius: 50%;
		    color: white;
			background-color: #279fc3;
    		box-shadow: 0 0px 5px grey;
    		transition: transform ease-in-out 0.3s,background-color ease-in-out 0.3s,color ease-in-out 0.3s,box-shadow ease-in-out 0.3s;
    		font-weight: bold;

		}

		#actionButton:hover{
			background-color: #fff;
			 color: #279fc3;
			 box-shadow: 0 0px 25px grey;
			 transform: scale(1.2,1.2);
		}

		#actionButton:focus {
		  outline: none;
		}

		#actionContainerClose{
			display: flex;
			align-items: center;
			justify-content: space-around;
			position: fixed;
			z-index: 101;
		    position: fixed;
		    top: 80%;
		    left: 85%;
		}
		#actionButtonClose{
			height: 80px;
		    width: 80px;
		    border-radius: 50%;
		    color: white;
			background-color: #ff2323;
    		box-shadow: 0 0px 5px grey;
    		transition: transform ease-in-out 0.3s,background-color ease-in-out 0.3s,color ease-in-out 0.3s,box-shadow ease-in-out 0.3s;
    		font-weight: bold;

		}
		#actionButtonClose:hover{
			background-color: #fff;
			 color: #ff2323;
			 box-shadow: 0 0px 25px grey;
			 transform: scale(1.2,1.2);
		}

		#actionButtonClose:focus {
		  outline: none;
		}
		#SystemListContainer{

			align-items: stretch;

		}
		.form-1{
			transform: translateY(0px) scaleY(1);
		    background-color: rgba(0,0,0,0.5);
		    transition: transform ease-in-out 0.3s,opacity ease-in-out 0.3s;
		    position: fixed;
		    z-index: 100;
		    width: 100%;
		    opacity: 0;

		}
		.slno{
			cursor:default;
			width: 28px;
			background-color: #afcadd;
   		 	border-radius: 0px;
   		 	padding-left: 5px;
   		 	padding-right: 5px;
		}
		.remove{
			background-color: white;
			border: 1px solid rgba(134, 134, 134, 0.29);
		}
		.info{

			order: 1;

			flex-shrink: 0;
			cursor: inherit;
			padding-left: 5px;
   		 	padding-right: 5px;
   		 	color: #515151;
   		 	width: 90%;

		}
		.formHolder{
			padding: 50px;
			background-color: white;

		}
		.customNav{
			    border-radius: 0px;
			    margin-bottom: 0px;
		}

		body{
			overflow-x: hidden;
			background-color: #cccccc;
		}
		.custButton{
			background-color: #5b81c7;
		   	padding: 30px;
		   	width: 80%;
		    height: 130px;
		   	box-shadow: 0 2px 5px #a2a2a2;
		    border-radius: 5px;
		    color: white;
		}
		.no-radius{
			border-radius: 0;
		}
	</style>
</head>
<body>
	 <!-- Modal Delete Warning-->
  <div class="modal fade" id="myModalDelete" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>


			  <h3 class="modal-title">Warning</h3>

        </div>
        <div class="modal-body">
          <div>
          	<div class="alert alert-danger">
			  <strong id="warningDesc" ></strong>
			</div>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">NO</button>
          <button type="button" class="btn btn-danger" id="applyDelete" >YES</button>
        </div>
      </div>

    </div>
  </div>
	 <!-- Modal HANDEL SHIFT-->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Shift Panel</h4>
        </div>
        <div class="modal-body">
          <div>
          	<h5 id="shiftModelAction" ></h5>
          </div>
          <div>
          	<select class="form-control" name="labname" id="LabListContainer">

			</select>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-success" onclick=requestShift() >REQUEST SHIFT</button>
        </div>
      </div>

    </div>
  </div>

	<!--- Main Web Page -->
	<div id="actionContainer">

		<button id="actionButton" class="btn" onClick =animateCustom(true)>ADD</button>

	</div>
	<div id="actionContainerClose" >
		<button id="actionButtonClose" class="btn" onClick =animateCustom(false) >CLOSE</button>
	</div>
	<!-- Nav bar -->

	<nav class="navbar navbar-inverse customNav">
	  <div class="container-fluid">
	    <div class="navbar-header">
	      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	      </button>
	      <a class="navbar-brand" href="#">LAB INCHARGE </a>
	    </div>
	    <div class="collapse navbar-collapse" id="myNavbar">

	      <ul class="nav navbar-nav navbar-right">

	        <li><a href="./logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
	      </ul>
	    </div>
	  </div>
	</nav>

	<div  id="view" class="fluid-container">
		<div class="row">

			<div class="col-sm-1">

			</div>
			<div class="col-sm-10">

				<div class="main fixHeight">
				<div>


					<nav class="navbar navbar-inverse no-radius">
					<div class="container-fluid">
					    <div class="navbar-header">
					      <div class="navbar-brand" ><?php echo $_SESSION["LABNAME"]?></div>
					    </div>


					  	<ul class="nav navbar-nav">
					        <li class="navitem active" id="system" ><a href="#" onclick=OnClickSystem() >Systems</a></li>
					         <li class="navitem " id="printer" ><a href="#"  onclick=OnClickPrinter() >Printers</a></li>
	       					<li class="navitem " id="hardware" ><a href="#" onclick=OnClickHardware() >Hardwares</a></li>
					        <li class="navitem "  id="maintanace" ><a href="#" onclick=OnClickMaintanance() >MAINTANANCE</a></li>


					     </ul>

					    <ul class="nav navbar-nav navbar-right" style="padding-right: 10px">



					    </ul>
					  </div>
					  <div class="container-fluid">
					    <div class="navbar-header">

					    </div>

					    <form class="navbar-form navbar-left system">
					      <div class="form-group">
					        <input id="search-barsystem" oninput=search() class="form-control" placeholder="SEARCH"></input>
					      </div>

					    </form>
					     <form class="navbar-form navbar-left printer">
					      <div class="form-group">
					        <input id="search-barprinter" oninput=search() class="form-control" placeholder="SEARCH"></input>
					      </div>

					    </form>
					    <form class="navbar-form navbar-left hardware">
					      <div class="form-group">
					        <input id="search-barhardware" oninput=search() class="form-control" placeholder="SEARCH"></input>
					      </div>

					    </form>
					    <div action="#" class="navbar-form navbar-left maintanace">
					    	<div class="form-group">
					        	<input class="form-control" id="fromDate" type="date" name="sdate" max="2017-12-31"></input>
					     	</div>
					     	<div class="form-group">
					       	 <input class="form-control" id="toDate" type="date" name="edate" min="2000-01-02"></input>
					     	</div>
						 	<button class="btn btn-success" onclick=findMaintananceRecord()>FIND</button>
						</div>

					    <ul class="nav navbar-nav navbar-right" style="padding-right: 10px">

					    	<button class="btn btn-default navbar-btn system" onClick=shiftAction() >SHIFT</button>
					       <!-- <button class="btn btn-danger navbar-btn system" onClick=warning() >DELETE</button>-->

					    </ul>
					  </div>
					</nav>

				</div>
				<table  class="table table-condensed table-hover table-striped  system">
					 <thead>
				      <tr>
				    	<th></th>
				        <th>SlNo</th>
				        <th>System Number</th>
				        <th>OS</th>
				        <th>Processor</th>
				        <th>Ram(GB)</th>
				        <th>Hdd</th>
				        <th>MonitorSize(cm)</th>
				        <th>Dvd</th>
				        <th>Brand</th>
				        <th>Make & Year</th>
				        <th>Warranty</th>

				      </tr>
				    </thead>
				     <tbody  id="SystemListContainer">

				     </tbody>

				</table>
				<div class="printer">
					<table  class="table table-condensed table-hover table-striped">
					 <thead>
				      <tr>
				    	<th></th>
				        <th>SlNo</th>
				        <th>Printer Number</th>
				        <th>Brand</th>
				        <th>Make & Year</th>
				        <th>In warranty</th>

				      </tr>
				    </thead>
				     <tbody id="PrinterListContainer" >

				     </tbody>

				</table>
				</div>
				<div class="hardware">
					<table  class="table table-condensed table-hover table-striped">
					 <thead>
				      <tr>
				    	<th></th>
				        <th>SlNo</th>
				        <th>Hardware Number</th>
				        <th>Hardware Description</th>
				        <th>Brand</th>
				        <th>Make & Year</th>
				        <th>In warranty</th>
				      </tr>
				    </thead>
				     <tbody id="HardwareListContainer">

				     </tbody>

				</table>
				</div>
				<div class="maintanace">
					<table  class="table table-condensed table-hover table-striped">
					 <thead>
				      <tr>
				    	<th></th>
				        <th>SlNo</th>
				        <th>Particular</th>
				        <th>Description</th>
				        <th>Warranty</th>
				        <th>Date(YYYY-MM-DD)</th>
				        <th>Budget Register page No.</th>
				        <th>Remark</th>
				      </tr>
				    </thead>
				     <tbody id="MaintainListContainer">

				     </tbody  >

				</table>
				</div>

			</div>
			<div class="col-sm-1">


			</div>
		</div>
	</div>

	<!-- FORM TO ADD SYSTEM -->
	<div  id="addFormsystem" class="form-1">
		<div  id="formContainersystem" class="form-c">
			<div class="row">

				<div class="col-sm-2">

				</div>
				<div class="col-sm-8 formHolder">
					<form name="add" action="./Database/system/add.php"  onsubmit="return validateForm()" method="post">


						<div class="form-group">
							<lable>Lab name: <?php echo $_SESSION["LABNAME"]; ?> </lable>
							<input type="hidden" class="form-control" name="labcode" value="<?php echo $_SESSION["LABID"]; ?>">
						</div>
						<div class="form-group">
							<lable>System number:</lable>
							<input type="text" class="form-control" name="systemcode">
						</div>
						<div class="form-group">
							<lable>Processor Details:</lable>
							<input type="text" class="form-control" name="processor_details">
						</div>

						<div class="form-group">
							<lable>Operating System:</lable>
							<input type="text" class="form-control" name="operating_system">
						</div>

						<div class="form-group">
							<lable>Ram:</lable>
							<input type="text" class="form-control" name="ram">
						</div>

						<div class="form-group">
							<lable>HDD:</lable>
							<input type="text" class="form-control" name="hdd">
						</div>

						<div class="form-group">
							<lable>Monitor Size:</lable>
							<input type="text" class="form-control" name="monitor_size">
						</div>

						<div class="checkbox">
							<lable><input type="checkbox" name="dvd" value="true">DVD:</lable>
						</div>

						<div class="form-group">
							<lable>Brand:</lable>
							<input type="text" class="form-control" name="brand">
						</div>

						<div class="form-group">
							<lable>Make and Year:</lable>
							<input type="text" class="form-control" name="make_and_year">
						</div>

						<div class="checkbox">
							<lable> <input type="checkbox" name="in_warrenty" value="true">In Warrenty:</lable>
						</div>

						<input type="submit" class="btn btn-success" value="Submit">
					</form>
				</div>
				<div class="col-sm-2">
				</div>
			</div>
		</div>
	</div>
	<!-- FORM TO ADD PRINTER -->
	<div  id="addFormprinter" class="form-1">
		<div  id="formContainerprinter" class="form-c">
			<div class="row">

				<div class="col-sm-2">

				</div>
				<div class="col-sm-8 formHolder">
					<form name="addPrinter" action="./Database/printer/add.php"  onsubmit="return validateForm()" method="post">


						<div class="form-group">
							<lable>Lab name: <?php echo $_SESSION["LABNAME"]; ?> </lable>
							<input type="hidden" class="form-control" name="labcode" value="<?php echo $_SESSION["LABID"]; ?>">
						</div>
						<div class="form-group">
							<lable>Printer number:</lable>
							<input type="text" class="form-control" name="compnumber">
						</div>
						<div class="form-group">
							<lable>Brand:</lable>
							<input type="text" class="form-control" name="brand">
						</div>

						<div class="form-group">
							<lable>Make and Year:</lable>
							<input type="text" class="form-control" name="make_and_year">
						</div>

						<div class="checkbox">
							<lable> <input type="checkbox" name="in_warrenty" value="true">In Warrenty:</lable>
						</div>

						<input type="submit" class="btn btn-success" value="Submit">
					</form>
				</div>
				<div class="col-sm-2">
				</div>
			</div>
		</div>
	</div>
	<!-- FORM TO ADD HARDWARE -->
	<div  id="addFormhardware" class="form-1">
		<div  id="formContainerhardware" class="form-c">
			<div class="row">

				<div class="col-sm-2">

				</div>
				<div class="col-sm-8 formHolder">
					<form name="addHardware" action="./Database/hardware/add.php"  onsubmit="return validateForm()" method="post">


						<div class="form-group">
							<lable>Lab name: <?php echo $_SESSION["LABNAME"]; ?> </lable>
							<input type="hidden" class="form-control" name="labcode" value="<?php echo $_SESSION["LABID"]; ?>">
						</div>
						<div class="form-group">
							<lable>Hardware number:</lable>
							<input type="text" class="form-control" name="compnumber">
						</div>
						<div class="form-group">
							<lable>Hardware Description:</lable>
							<input type="text" class="form-control" name="hardwaredesc">
						</div>
						<div class="form-group">
							<lable>Brand:</lable>
							<input type="text" class="form-control" name="brand">
						</div>

						<div class="form-group">
							<lable>Make and Year:</lable>
							<input type="text" class="form-control" name="make_and_year">
						</div>

						<div class="checkbox">
							<lable> <input type="checkbox" name="in_warrenty" value="true">In Warrenty:</lable>
						</div>

						<input type="submit" class="btn btn-success" value="Submit">
					</form>
				</div>
				<div class="col-sm-2">
				</div>
			</div>
		</div>
	</div>
	<!-- FORM TO ADD MAINTANANCE -->
	<div  id="addFormmaintanace" class="form-1">
		<div  id="formContainermaintanace" class="form-c">
			<div class="row">

				<div class="col-sm-2">

				</div>
				<div class="col-sm-8 formHolder">
					<form name="addMaintanance" action="./Database/maintain/add.php"  onsubmit="return validateForm()" method="post">


						<div class="form-group">
							<lable>Lab name: <?php echo $_SESSION["LABNAME"]; ?> </lable>
							<input type="hidden" class="form-control" name="labcode" value="<?php echo $_SESSION["LABID"]; ?>">
						</div>
						<div class="form-group">
							<lable>Particular:</lable>
							<input type="text" class="form-control" name="particular">
						</div>
						<div class="form-group">
							<lable>Description:</lable>
							<input type="text" class="form-control" name="description">
						</div>
						<div class="checkbox">
							<lable> <input type="checkbox" name="warranty" value="true">Warranty</lable>
						</div>
						<div class="form-group">
							<lable>Date:</lable>
							<input type="date" class="form-control" name="date">
						</div>
						<div class="form-group">
							<lable>Budget Register page number:</lable>
							<input type="text" class="form-control" name="breg">
						</div>
						<div class="form-group">
							<lable>Remark:</lable>
							<textarea rows="4" cols="50" class="form-control" name="remark"></textarea>
						</div>
						<input type="submit" class="btn btn-success" value="Submit">
					</form>
				</div>
				<div class="col-sm-2">
				</div>
			</div>
		</div>
	</div>
	<?php include "adBanner.php";?>
</body>
</html>
