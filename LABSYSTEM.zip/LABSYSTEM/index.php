<?php
		session_start();

		require('database/connection.php');

?>
<!DOCTYPE html>
<html>
<head lang="en-US">

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons"  rel="stylesheet">

	 <script>
	 $(document).ready(populateLabList());
	 function populateLabList(){
	 	fetch('./Database/lab/view')
		  .then(
		    function(response) {
		      if (response.status !== 200) {
		        console.log('Looks like there was a problem. Status Code: ' +
		          response.status);
		        return;
		      }

		      // Examine the text in the response
		      response.json().then((data)=>{


		      	data.forEach((item,index)=>{
		      		//var element = "<div  class='list-group-item card'><div class='slno'>"+(index+1)+".</div><div class='info' onClick=populateSystemList("+item.id+")>"+item.labName+"</div><a href='editSystem?systemID="+item.id+"' type='button' class='btn btn-warning edit' ><span class='glyphicon glyphicon-edit'></span></a><button type='button' class='btn btn-danger delete'  onClick=deleteLabItem("+item.id+")><span class='glyphicon glyphicon-trash'></span></button></div>";

		      		var element = "<option class='form-control' value='"+item.id+"'>"+item.labName+"</option>";

		      		$('#LabListContainer').append(element);
		      	});
		      });
		    }
		  )
		  .catch(function(err) {
		    console.log('Fetch Error :-S', err);
		  });
	 }
	 </script>
	 <style>
	 	body{
	 		    background: url(./img/back.png);
			    background-size: cover;
			    overflow: hidden;
	 	}
	 	.bottom{


			    padding: 40px;


	 	}
	 	.ptitle{
	 		    font-size: 60px;
    			color: rgba(255, 255, 255, 0.54);
	 	}
	 	.titleContainer{
	 		    margin: 5%;
	 	}
	 </style>
</head>
<body>
	 <?php if(isset($_SESSION["error"]) ){

	 				if($_SESSION["error"] != ""){
					    echo "<div class='alert alert-danger alert-dismissable'>
		   				 		<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
		     				    <strong>Danger!</strong>".$_SESSION["error"]."</div>";

		    				  $_SESSION["error"] = "";
		    		}

		}
		else
		{

		}?>
	<div class="fluid-container titleContainer">
		<div class="row">
			<div class="col-sm-12"></div>
				<center><h1 class="ptitle">LAB SYSTEM MANAGEMENT</h1></center>
			</div>
		</div>
	</div>
	<div class="fluid-container bottom">

		<div class="row">
			<div class="col-sm-2">

			</div>
			<div class="col-sm-3">
			 <div class="panel panel-default">
				<div class="panel-heading"><h3 style="color: #386590;">ADMIN LOGIN</h3></div>
				 <div class="panel-body"><form name="adminLogin" action="./Database/auth.php"  onsubmit="return validateForm()" method="post">
					<input type="hidden" name="formname" value="adminLogin"/>
					<div class="form-group">
						<input type="text" name="username" placeholder="Username" class="form-control"></input>
					</div>
					<div class="form-group">
						<input type="password" name="password" placeholder="Password" class="form-control"></input>
					</div>
					<input class="btn btn-success" type="submit" value="LogIn"></form>
				</form>
				</div>
			</div>
			</div>
			<div class="col-sm-1">
			</div>
			<div class="col-sm-4">
			 <div class="panel panel-default">
				 <div class="panel-heading"><h3 style="color: #5095a3;">LAB LOGIN</h3></div>
				<div class="panel-body"><form name="labLogin" action="./Database/auth.php"  onsubmit="return validateForm()" method="post">
					<input type="hidden" name="formname" value="labLogin"/>
					<div class="form-group">
						<select class="form-control" name="labname" id="LabListContainer">

						</select>
					</div>
					<div class="form-group">
						<input type="password" name="password" placeholder="Password" class="form-control"></input>
					</div>
					<input class="btn btn-success" type="submit" value="LogIn"></form>
				</form></div>
			</div>
			</div>
			<div class="col-sm-2">
			</div>
		</div>
	</div>
	<div  class="fluid-container" >
	<div class="row">
		<div class="col-sm-12">
			<div class="design" style=" background-color: rgba(101, 95, 138, 0.26);;padding: 15px">
				<center><h4>DESIGN AND DEVELOPED BY</h4></center>
				<center><h4>ASHWANI ARYA <a href="http://www.syncoders.com">(www.syncoders.com)</a></center>
			</div>
		</div>
	</div>
</div>
</body>
</html>
