
<?php
	session_start();
	//echo $_SESSION["login"];

	if(!isset($_SESSION["login"])){
		if(!$_SESSION["login"]){


			session_destroy();
			header("Location: ./index.php");
	      	die();
		}
	}
?>
<!DOCTYPE html>
<html>
<head lang="en-US">

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons"  rel="stylesheet">
	 <link rel="stylesheet" href="css/st.css">
	<script>
	function validateForm(){
		return true;
	}
	$( document ).ready(()=>{
		populateLabList();
		populateSystemList(1);
		populateNotification();
		//$("body").height($(document).innerHeight());
		//$(".fixHeight").innerHeight($("body").innerHeight());

	});

	$(window).ready(()=>{
		//$("#formContainer").hide();
		$("#actionContainerClose").hide();
	});

	var labs=[];
	function populateLabList(){
		fetch('./Database/lab/view')
		  .then(
		    function(response) {
		      if (response.status !== 200) {
		        console.log('Looks like there was a problem. Status Code: ' +
		          response.status);
		        return;
		      }

		      // Examine the text in the response
		      response.json().then((data)=>{

		      	console.log(data);
		      	data.forEach((item,index)=>{
		      		var newLab = {id:item.id,name:item.labName};
		      		labs.push(newLab);
		      		var element = "<tr><td>"+(index+1)+".</td><td onClick=populateSystemList("+item.id+")>"+item.labName+"</td><td>"+item.nosystem+"</td><td><button type='button' class='btn btn-info'  onClick=showAlert(\""+item.password+"\") ><span class='glyphicon glyphicon-eye-open'></span></button></td><td><button type='button' class='btn btn-danger'  onClick=deleteItem("+item.id+")><span class='glyphicon glyphicon-trash'></span></button></td></tr>";


		      		$('#LabListContainer').append(element);
		      	});
		      });

		      console.log(labs);
		    }
		  )
		  .catch(function(err) {
		    console.log('Fetch Error :-S', err);
		  });
	}
	function populateSystemList(id){
		clearSystem();


		labs.forEach((item,index)=>{

			if(item.id === ""+id){

				$("#labNameTitle").html(item.name);
			}

		});

		fetch('./Database/system/view?labID='+id)
		  .then(
		    function(response) {
		      if (response.status !== 200) {
		        console.log('Looks like there was a problem. Status Code: ' +
		          response.status);
		        return;
		      }
		      console.log(response);
		      // Examine the text in the response

		      response.json().then((data)=>{


		      	data.forEach((item,index)=>{

		      		var element = "<tr class='list'><td>"+(index+1)+".</td><td>"+item.systemcode+"</td><td>"+item.operating_system+"</td><td>"+item.processor_details+"</td><td>"+(item.ram)+"</td><td>"+(item.hdd)+"</td><td>"+(item.monitor_size)+"</td><td>"+(item.dvd=='true'?'Yes':'No')+"</td><td>"+(item.brand)+"</td><td>"+(item.make_and_year)+"</td><td>"+(item.in_warrenty=='true'?'Yes':'No')+"</td></tr>";
		      		//var element = "<div  class='list-group-item card list'><div class='slno'>"+(index+1)+".</div><div class='info' >"+item.operating_system+"</div><a href='editSystem?systemID="+item.id+"' type='button' class='btn btn-warning edit' ><span class='glyphicon glyphicon-edit'></span></a><button type='button' class='btn btn-danger delete'  onClick=deleteItem("+item.id+")><span class='glyphicon glyphicon-trash'></span></button></div>";


		      		$('#SystemListContainer').append(element);
		      	});
		      });
		    }
		  )
		  .catch(function(err) {
		    console.log('Fetch Error :-S', err);
		  });
	}

	function populateNotification(){
		fetch('./Database/system/viewNotification?action=view')
		  .then(
		    function(response) {
		      if (response.status !== 200) {
		        console.log('Looks like there was a problem. Status Code: ' +
		          response.status);
		        return;
		      }

		      // Examine the text in the response
		      response.json().then((val)=>{


		      	if(val.status === "true"){
		      		data = val.data;
		      		console.log(data);
		      		data.forEach((item,index)=>{
		      		var element = "<div  class='list-group-item card'><div class='slno'>"+(index+1)+".</div><div class='info' >Shift request pending</div><button type='button' class='btn btn-info delete'  onClick=viewNoti("+item.nid+")>VIEW</button></div>";


		      		$('#NotiListContainer').append(element);
		      	});
		      	}
		      	else{

		      	}

		      });
		    }
		  )
		  .catch(function(err) {
		    console.log('Fetch Error :-S', err);
		  });
	}

	function viewNoti(nid){
		fetch('./Database/system/viewTempSystem?action=list&nid='+nid)
		  .then((response)=>{

		  	 if (response.status !== 200) {
		        console.log('Looks like there was a problem. Status Code: ' +
		          response.status);
		        return;
		      }

		      response.json().then((val)=>{
		      console.log(val);

		      	if(val.status === "true"){
		      		data = val.data;

		      		var from;
		      		var to;
		      		var nameFrom;
		      		var nameTo;
		      		data.forEach((item,index)=>{
			      		from = item.from;
			      		to = item.to;
		      		});

		      		labs.forEach((item,index)=>{

		      			if(from == item.id){
		      				nameFrom = item.name;
		      			}
			      		if(to == item.id){
		      				nameTo = item.name;
		      			}
		      		});

		      		$("#shiftModelAction").html("Request to shift <strong>"+val.noOfSystem+"</strong> from <strong>"+nameFrom+"</strong> system to <strong>"+nameTo+"</strong>");
					$("#myModal").modal();
					$("#applyShift").on("click",()=>{applyShift(nid)});
		      	}
		      	else{

		      	}

		      });

		  })
		  .catch((err)=>{
		  	console.log('Fetch Error :-S', err);
		  });
	}
	function applyShift(nid){
		fetch('./Database/system/applyShift?nid='+nid)
		  .then((response)=>{
		  	if (response.status !== 200) {
		        console.log('Looks like there was a problem. Status Code: ' +
		          response.status);
		        return;
		      }

		      response.json().then((data)=>{

		      	if(data.status === "true"){
		      		location.reload();
		      	}

		      });
		  })
		  .catch((err)=>{

		  });
	}

	function warning(){
		$("#myModalDelete").modal({backdrop: "static"})
	}


	function deleteItem(id){
		console.log("Deleting : "+id);
		warning();
		$("#applyDelete").on("click",()=>{serverCallDelete(id);});

	}

	function serverCallDelete(id){
		fetch('./Database/lab/delete?labID='+id)
		  .then(
		    function(response) {
		      if (response.status !== 200) {
		        console.log('Looks like there was a problem. Status Code: ' +
		          response.status);
		        return;
		      }

		      // Examine the text in the response
		      response.json().then((data)=>{
		      	console.log(data);
		      	if(data.status === true){
		      		location.reload();
		      	}
		      });
		    }
		  )
		  .catch(function(err) {
		    console.log('Fetch Error :-S', err);
		  });
	}


	function animateCustom(val){
		var targetheight = $("#view").css("height");


		var value = "translateY(-"+(targetheight)+")";
		console.log(value);
		if(val){

			$("#formContainer").show();
			$("#actionContainerClose").show();
			$("#addForm").css("transform",value).css("position","absolute").css("opacity","1");

		}
		else{

			$("#addForm").css("transform","translateY(0px)").css("position","fixed").css("opacity","0");
			//$("#formContainer").hide();
			$("#actionContainerClose").hide();

		}

	}
	function clearSystem(){
		$(".list").remove();
	}
	function validateForm(){
		return true;
	}

	function showAlert(password){

		$("#password").html("PASSWORD : "+password);
		$("#showPass").modal();
	}
	</script>
	<style>
		.main{
			min-height: 500px;
			background-color: #f1f1f1;
		    padding-left: 10px;
		    padding-right: 10px;
		    padding-top: 20px;
		    padding-bottom: 20px;
		    margin-top: 20px;
		    margin-bottom: 20px;
		    box-shadow: 0 4px 4px #9b9b9b;
		    display: flex;
		    flex-direction: column;
		}
		body{
			overflow-x: hidden;
			background-color: #cccccc;
		}
		#actionContainer{
			display: flex;
			align-items: center;
			justify-content: space-around;
			position: fixed;
			z-index: 50;
		    position: fixed;
		    top: 80%;
		    left: 85%;
		}
		#actionButton{
			height: 80px;
		    width: 80px;
		    border-radius: 50%;
		    color: white;
			background-color: #279fc3;
    		box-shadow: 0 0px 5px grey;
    		transition: transform ease-in-out 0.3s,background-color ease-in-out 0.3s,color ease-in-out 0.3s,box-shadow ease-in-out 0.3s;
    		font-weight: bold;

		}

		#actionButton:hover{
			background-color: #fff;
			 color: #279fc3;
			 box-shadow: 0 0px 25px grey;
			 transform: scale(1.2,1.2);
		}

		#actionButton:focus {
		  outline: none;
		}

		#actionContainerClose{
			display: flex;
			align-items: center;
			justify-content: space-around;
			position: fixed;
			z-index: 101;
		    position: fixed;
		    top: 80%;
		    left: 85%;
		}
		#actionButtonClose{
			height: 80px;
		    width: 80px;
		    border-radius: 50%;
		    color: white;
			background-color: #ff2323;
    		box-shadow: 0 0px 5px grey;
    		transition: transform ease-in-out 0.3s,background-color ease-in-out 0.3s,color ease-in-out 0.3s,box-shadow ease-in-out 0.3s;
    		font-weight: bold;

		}
		#actionButtonClose:hover{
			background-color: #fff;
			 color: #ff2323;
			 box-shadow: 0 0px 25px grey;
			 transform: scale(1.2,1.2);
		}

		#actionButtonClose:focus {
		  outline: none;
		}
		#SystemListContainer{

			align-items: stretch;

		}
		#addForm{
			transform: translateY(0px) scaleY(1);
		    background-color: rgba(0,0,0,0.5);
		    transition: transform ease-in-out 0.3s,opacity ease-in-out 0.3s;
		    position: fixed;
		    z-index: 100;
		    width: 100%;
		    opacity: 0;

		}
		.slno{
			cursor:default;
			width: 28px;
			background-color: #fff;
   		 	border-radius: 0px;
   		 	padding-left: 5px;
   		 	padding-right: 5px;
		}
		.remove{
			background-color: white;
			border: 1px solid rgba(134, 134, 134, 0.29);
		}
		.info{

			order: 1;

			flex-shrink: 0;
			cursor: inherit;
			padding-left: 5px;
   		 	padding-right: 5px;
   		 	color: #515151;
   		 	width: 80%;

		}
		.formHolder{
			padding: 50px;
			background-color: white;

		}
		.customNav{
			    border-radius: 0px;
			    margin-bottom: 0px;
		}

		.form-holder{


		}

		.form-name{
			flex-grow: 1;
		}

		.form-pass{
			flex-grow: 1;
		}

		.form-submit{
			flex-grow: 1;
		}

		.p_left{
			padding-right: 0px;
			padding-left: 25px;

		}
		.p_right{
			padding-left: 0px;
			padding-right: 25px;
		}
		.c_form-control{
			width: 100% !important;
		}
		.delete{
			order: 3;
			flex-grow: 1;
			border-radius: 2px;
			padding:0px;
			height: 20px;
		}
	</style>
</head>
<body>


	<div class="modal fade" id="showPass" role="dialog">
	    <div class="modal-dialog modal-sm">
	      <div class="modal-content">
	        <div class="modal-header">
	          <button type="button" class="close" data-dismiss="modal">&times;</button>
	          <h4 class="modal-title">INFO</h4>
	        </div>
	        <div class="modal-body">
	          <p id="username"></p>
	           <p id="password"></p>
	        </div>
	        <div class="modal-footer">
	          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	        </div>
	      </div>
	    </div>
	  </div>
	<!-- Modal Delete Warning-->
	  <div class="modal fade" id="myModalDelete" role="dialog">
	    <div class="modal-dialog">

	      <!-- Modal content-->
	      <div class="modal-content">
	        <div class="modal-header">
	          <button type="button" class="close" data-dismiss="modal">&times;</button>


				  <h3 class="modal-title">Warning</h3>

	        </div>
	        <div class="modal-body">
	          <div>
	          	<div class="alert alert-danger">
				  <strong>Are you sure you want to delete this lab?</strong>
				</div>
	          </div>

	        </div>
	        <div class="modal-footer">
	          <button type="button" class="btn btn-default" data-dismiss="modal">NO</button>
	          <button type="button" class="btn btn-danger" id="applyDelete" >YES</button>
	        </div>
	      </div>

	    </div>
	  </div>
	 <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Notification Panel</h4>
        </div>
        <div class="modal-body">
          <div>
          	<h5 id="shiftModelAction" ></h5>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-success" id="applyShift" >APPLY SHIFT</button>
        </div>
      </div>

    </div>
  </div>


	<!--- Main Web Page -->

	<!-- Nav bar -->

	<nav class="navbar navbar-inverse customNav">
	  <div class="container-fluid">
	    <div class="navbar-header">
	      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	      </button>
	      <a class="navbar-brand" href="#">ADMIN</a>
	    </div>
	    <div class="collapse navbar-collapse" id="myNavbar">

	      <ul class="nav navbar-nav navbar-right">

	        <li><a href="./logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
	      </ul>
	    </div>
	  </div>
	</nav>

	<div  id="view" class="fluid-container">
		<div class="row">

			<div class="col-sm-4 p_left">
				<div class="main labViewContainer fixHeight">
					<div>
						<div class="card-block">

							<table  class="table table-condensed table-hover table-striped">
								<thead>
							      	<tr>

								        <th>SlNo</th>
								        <th>Lab Name</th>
								        <th>No of Systems</th>

							      	</tr>
						    	</thead>
						     	<tbody  id="LabListContainer">

						     	</tbody>

							</table>
						</div>
						<div class="card-footer">
							<form name="add" class="form-inline form-holder" action="./Database/lab/add.php"  onsubmit="return validateForm()" method="post">
							<table class="table">
								<tbody>
									<tr>
									<td>
										<div class="form-group form-name">
											<input type="text" placeholder="Lab Name" class="form-control c_form-control" name="labName">
										</div>
									</td>
									<td>
										<div class="form-group form-pass">

											<input type="password" placeholder="Password" class="form-control c_form-control" name="pass">
										</div>
									</td>
									<td>
										<input type="submit" class="btn btn-success form-submit" value="ADD">
									</td>
									</tr>
								</tbody>
							</table>
							</form>
						</div>
					</div>
					<div class="list-group" id="NotiListContainer">
					</div>

				</div>
			</div>
			<div class="col-sm-8 p_right">
				<div class="main ">

					<h2 id="labNameTitle" ></h2>
					<div class="fixHeight" >
						<table  class="table table-condensed table-hover table-striped table-responsive">
							<thead>
						      	<tr>

							        <th>SlNo</th>
							        <th>System Number</th>
							        <th>OS</th>
							        <th>Processor</th>
							        <th>Ram(GB)</th>
							        <th>Hdd</th>
							        <th>MonitorSize(cm)</th>
							        <th>Dvd</th>
							        <th>Brand</th>
							        <th>Make & Year</th>
							        <th>Warrenty</th>
						      	</tr>
					    	</thead>
					     	<tbody id="SystemListContainer">

					     	</tbody>

						</table>
					</div>
			</div>

		</div>
	</div>
	<?php include "adBanner.php";?>
</body>
</html>
