<?php

	session_start();
	$SystemID = "";

	$labID = $processor_details = $operating_system = $ram = $hdd = $monitor_size= $dvd = $brand  = $make_and_year = $in_warrenty = $systemcode = "";
	if ($_SERVER["REQUEST_METHOD"] == "GET") {

		$SystemID = test_input($_GET["systemID"]);

	}
	else{

	}

	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}


	//echo "You want to edit ".$SystemID." with systemCode ";

	require('/database/connection.php');

	$sql = "SELECT * FROM _system WHERE `_system`.`systemID`=".$SystemID;
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
	    // output data of each row


	    while($row = $result->fetch_assoc()) {

	    	$labID = $row["labID"];
	    	$processor_details = $row["processor_details"];
	    	$operating_system = $row["operating_system"];
	    	$ram = $row["ram"];
	    	$hdd = $row["hdd"];
	    	$monitor_size = $row["monitor_size"];
	    	$dvd = $row["dvd"];
	    	$brand = $row["brand"];
	    	$make_and_year = $row["make_and_year"];
	    	$in_warrenty = $row["in_warrent"];
	    	$systemcode = $row["systemCode"];
	    	//echo $systemcode;



	    }
	} else {
	   // echo "0 results";
	}
	$conn->close();
?>



<html>
<head lang="en-US">

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<script>
	function validateForm(){
		return true;
	}

	</script>
</head>

<body>
	<div class="container">
		<div class="row">

			<div class="col-lg-3">
			</div>
			<div class="col-lg-6">
				<form name="edit" action="./Database/system/edit.php" onsubmit="return validateForm()" method="post">




					<div class="form-group">
						<lable>Lab name: <?php echo $_SESSION["LABNAME"];?> </lable>
						<input type="hidden" class="form-control" name="labcode" value=<?php echo $labID?> readonly>
					</div>
					<div class="form-group">
						<input type="hidden" class="form-control" name="systemID" value=<?php echo $SystemID?> readonly>
					</div>
					<div class="form-group">
						<lable>System Number:</lable>
						<input type="text" class="form-control" name="systecode" value='<?php echo $systemcode?>'>
					</div>
					<div class="form-group">
						<lable>Processor Details:</lable>
						<input type="text" class="form-control" value=<?php echo $processor_details?> name="processor_details">
					</div>

					<div class="form-group">
						<lable>Operating System:</lable>
						<input type="text" class="form-control"  value=<?php echo $operating_system?> name="operating_system">
					</div>

					<div class="form-group">
						<lable>Ram:</lable>
						<input type="text" class="form-control" value=<?php echo $ram?> name="ram">
					</div>

					<div class="form-group">
						<lable>HDD:</lable>
						<input type="text" class="form-control" value=<?php echo $hdd?> name="hdd">
					</div>

					<div class="form-group">
						<lable>Monitor Size:</lable>
						<input type="text" class="form-control" value=<?php echo $monitor_size?> name="monitor_size">
					</div>

					<div class="checkbox">
						<lable><input type="checkbox" name="dvd" <?php echo $dvd=='true'?'checked':'' ?> >DVD:</lable>
					</div>

					<div class="form-group">
						<lable>Brand:</lable>
						<input type="text" class="form-control" value=<?php echo $brand?> name="brand">
					</div>

					<div class="form-group">
						<lable>Make and Year:</lable>
						<input type="text" class="form-control" value=<?php echo $make_and_year?> name="make_and_year">
					</div>

					<div class="checkbox">
						<lable> <input type="checkbox" name="in_warrenty" <?php echo $in_warrenty=='true'?'checked':''?>  >In Warrenty:</lable>
					</div>
					<a class="btn btn-warning" href="./LabView.php">Cancel</a>
					<input type="submit" class="btn btn-success" value="Submit">
				</form>
			</div>
			<div class="col-lg-3">
			</div>
		</div>
	</div>
</body>
</html>
